
package project.pkg3;


public class P3Model {

   
    public static void main(String[] args) {
       model model2 = new model();
       //model2.checkAvailableRooms("2018-12-02", "2018-12-03");
      // model2.makeReservation("shady", "2018-03-03", "2018-03-05", 200, 1215);
       //model2.makeCustomer("eddie", "bones", "handles");
       model2.paymentInfo("12345678", "12/12", "029", "1234 main st", "GA", "22079", "handles");
    }
    
}
